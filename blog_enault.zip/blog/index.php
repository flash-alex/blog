<?php
require_once '../class/Message.php';
require_once '../class/GuestBook.php';
$guestbook = new GuestBook(__DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'messages');
if (isset($_POST['title'], $_POST['message'])) {
    $message = new Message($_POST['title'], $_POST['message']);
        $guestbook->addMessage($message);
        $_POST = [];
    }

$messages = $guestbook->getMessages();
$title = "Le blog";
require '../elements/header.php'; 
?>
<header>
<div class="container">
    <h1>Mon blog</h1>

    <form action="" method="post">
        <div class="form-group">
            <input value="<?= htmlentities($_POST['title'] ?? '') ?>" type="text" name="title" placeholder="titre" class="form-control <?= isset($errors['title']) ? 'is-invalid' : '' ?>">
            <?php if (isset($errors['title'])): ?>
            <div class="invalid-feedback"><?= $errors['title'] ?></div>
            <?php endif ?>
        </div>
        <div class="form-group">
            <textarea name="message" placeholder="Votre article" class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>"><?= htmlentities($_POST['message'] ?? '') ?></textarea>
            <?php if (isset($errors['message'])): ?>
            <div class="invalid-feedback"><?= $errors['message'] ?></div>
            <?php endif ?>
        </div>
        <div class="button" >
        <button class="btn btn-primary">Envoyer</button>
        </div>   
    </form>
</header>
    <?php if (!empty($messages)): ?>
    <h1 class="mt-4">Les articles</h1>

    <?php foreach($messages as $message): ?>
        <?= $message->toHTML() ?>
    <?php endforeach ?>

    <?php endif ?>
</div>