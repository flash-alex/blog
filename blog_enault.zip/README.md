blog créé par alexis
avec la ressource https://www.youtube.com/watch?v=Rh7mXaZl1oc&ab_channel=Grafikart.fr

accéder a la page d'acceuil afin de lire les articles http://localhost/

accéder a la création des articles http://localhost/blog
