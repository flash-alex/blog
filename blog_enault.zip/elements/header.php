<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>mon blog</title>
    <style>* {
  box-sizing: border-box;
}
/*tete page*/
header {
  background-color: #4c00ff;
  color: rgb(255, 255, 255);
  text-align: center;
  padding: 30px 40px;
  border-radius: 20px;
  max-height: auto;
}

/*tete page*/
div {
margin-top: 10px;
  color: rgb(255, 255, 255);
  text-align: center;
  padding: 30px 40px;
  border-radius: 20px;
  margin-bottom: 10px;
}

/*corp fond noir */
body {
  background-color: #AC500F;
  color: #fff;
  text-align: center;
}

  /*bouton ajout*/
    button {
      padding: 10px;
      width: 25%;
      background: #d9d9d9;
      color: #555;
      float: left;
      text-align: center;
      font-size: 16px;
      cursor: pointer;
      transition: 0.3s;
      border-radius: 20px;
      
    } 

/*saisie*/
input {
  margin: 0;
  border: none;
  border-radius: 0;
  width: 75%;
  padding: 10px;
  float: left;
  font-size: 16px;
  border-radius: 20px;
}
textarea {
  margin: 0;
  border: none;
  border-radius: 0;
  width: 75%;
  padding: 10px;
  float: left;
  font-size: 16px;
  border-radius: 20px;
}
/*souri sur bouton*/
button:hover {
  background-color: #bbb;
}
</style>
</head>
<body>


    