<?php
class Message {

    private $title;
    private $message;
    private $date;
public static function fromJSON(string $json): Message
{
$data = json_decode($json, true);
return new self($data['title'], $data['message'], new DateTime("@" . $data['date']));
}

      
    public function __construct(string $title, string $message, ?DateTime $date = null)
    {
        $this->title = $title;
        $this->message = $message;
        $this->date = $date ?: new DateTime();
    }

    public function toHTML(): string
    {
        $title = htmlentities($this->title);
        $this->date->setTimezone(new DateTimeZone('Europe/Paris'));
        $date = $this->date->format('d/m/Y à H:i');
        $message = nl2br(htmlentities($this->message));
        return <<<HTML
        <p>
            <strong>{$title}</strong> <em>le {$date}</em><br>
            {$message}
        </p>
HTML;
    }

    public function toJSON(): string
    {
        return json_encode([
            'title' => $this->title,
            'message' => $this->message,
            'date' => $this->date->getTimestamp()
        ]);
    }

}